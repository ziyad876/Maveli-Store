import React from "react";

function MainBody(){
    return <div className="frc">
                <div className="frc1 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <h1>Make A Change</h1>
                    <h4>Make A Better Future <br /> expirience With Honor</h4>
                    <button type="button" className="button btn-dark">Buy</button>
                </div>
                <div className="frc2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6"> 
                        <button className="butn1">
                            Buy
                        </button>
                    </div>
            </div>
            }

export default MainBody